<?php

/* SPLIT PROXY FROM URL TO QUERY. QUERY: ALL INSIDE THE 'S' PARAMETER */
        $url = str_replace(" ", "%20", $_GET['url']);

/* SET INTERNAL PROXY */
        $proxy = "";
        $proxy = "http://wwwcache.ebi.ac.uk:3128/";
        //$proxy = "http://wwwcache.sanger.ac.uk:3128/";


/* CURL CONFIGURARTION */
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		  curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        if(strlen($proxy) != 0){
                //curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1); 
                curl_setopt($ch, CURLOPT_PROXY, "$proxy");
        }
        /* Don't return HTTP headers in the response */     
        curl_setopt($ch, CURLOPT_HEADER, false);


/* EXECUTE CURL */
       	$data = curl_exec($ch);
     
/* SET HEADERS USING CONTENT TYPE FROM ORIGINAL SOURCE */       	
       	$curlinforContentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
      	$ContentType = substr($curlinforContentType, 0, strpos($curlinforContentType, ";"));
       	header("Content-Type: " . $ContentType); 
       	
/* PRINT RESPONSE */       	
        	curl_close($ch);
			echo $data;
        
         
?>